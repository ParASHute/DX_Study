#pragma once
#include "../Global/Define/GlobalDefine.h"
class cMonster{
private:

protected:
	struct MonsterState {
		string MonTag;
		int Hp;
		int Mp;
		int ad;
		int ap;
		int adDef;
		int apDef;
		int EXP;
	};
	struct Burn {
		bool burn = false;
		int turn = 0;
	};
	struct Bleed {
		bool bleeding = false;
		int turn = 0;
	};
	struct Sturn {
		bool sturn = false;
		int turn = 0;
	};
	struct Taunt {
		bool taunt = false;
		int turn = 0;
	};
	
	MonsterState MonState;
	Burn burnning;
	Bleed Bleeding;
	Sturn Sturned;
	Taunt Tuanted;

	string MonName;
	string SkillName_1;
	string SkillName_2;
	string SkillName_3;
	string SkillName_4;

	/*
		ĸ��ȭ�� �ϴ� ������ ������ �Ű澲�� ���ؼ���
		�Ʒ� �ۺ����� �ִ� ��� �Լ���(������, �Ҹ��� ����) 
		�� ����(protected)������ �����Ѵ�
		�̶� �Լ����� ���� �����Լ�ȭ(virtual)�Ͽ�
		�ڽ� Ŭ�󽺿��� �������̵� �ؼ� ����Ѵ�.

		���� ó�� �����(1)
		class �ڽ� : protected �θ� { };�� ���·� ����� �����ϳ�

		�ۺ����� ���� �� �����(2)
		class �ڽ� : public �θ� { };�� ���·� ����ؾ� �������� Ȱ���Ҽ� �ִ�.

		�����̺���Ʈ�� ���� �� �����(3)
		class �ڽ� : �θ� { };

		�̶��� �θ�Ŭ�� �տ� �ۺ����� �ٰ� �Ⱥٰ��� ���̴� 
		�������� ��ġ�� �ִ�.

		(1) : ������ �Ҹ��ڰ� protected������ ����
		(2) : ������ �Ҹ��ڰ� public������ ����
	*/
public:
	// ������ �Ҹ���
	cMonster() { }
	cMonster(cMonster& monster);
	~cMonster() { }

	// �����Լ�(�����)
	// ����� ���� 
	virtual void SetName() { }
	virtual void SetMonState() { }
	virtual void SetHp(int dam) { }
	virtual void PrintMonHp() { }

	virtual void SetBurn(int turn) { }
	virtual void SetBurnTurn() { }
	virtual void SetBleed(int turn) { }
	virtual void SetBleedTurn() { }
	virtual void SetSturn(int turn) { }
	virtual void SetSturnTurn() { }
	virtual void SetTunt(int turn) { }
	virtual void SetTuntTurn() { }

	virtual void Skill_1() { }
	virtual void Skill_2() { }
	virtual void Skill_3() { }
	virtual void Skill_4() { }
	

	// ����� ����
	virtual MonsterState GetMonState() const { return this->MonState; }
	virtual Burn GetBurn() const { return this->burnning; }
	virtual Bleed GetBleed() const { return this->Bleeding; }
	virtual Sturn GetSturn() const { return this->Sturned; }
	virtual Taunt GetTaunt() const { return this->Tuanted; }
	virtual string GetName() const { return this->MonName; }
	virtual void PrintfHP() {  }

	virtual string GetSkill_1Name() const { return this->SkillName_1; }
	virtual string GetSkill_2Name() const { return this->SkillName_2; }
	virtual string GetSkill_3Name() const { return this->SkillName_3; }
	virtual string GetSkill_4Name() const { return this->SkillName_4; }
};

// ��ĭ�� ������ ���� (Ȥ�ø��� ����)
class Blank : public cMonster {
public:
	Blank();
	~Blank();

	void SetName() override { this->MonName = "Blank"; }
	void SetMonState() override { this->MonState.Hp = 0; }
};

// ���
// 1�������� (�ʿ�)
class Slime : public cMonster { // ������
public:
	// ������ �Ҹ���
	Slime();
	~Slime();

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;

	// ���� 
	void SetName() override { this->MonName = "������"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState()  const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }
};
class Gobllin : public cMonster { // ������
public:
	// ������ �Ҹ���
	Gobllin();
	~Gobllin();

	// ���� 
	void SetName() override { this->MonName = "������"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Kobold : public cMonster { // �ں�Ʈ
public:
	Kobold();
	~Kobold();

	// ���� 
	void SetName() override { this->MonName = "������"; }
	void SetMonState() override ;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class LizardMan : public cMonster{ // ���ڵ��
public:
	LizardMan();
	~LizardMan();

	// ���� 
	void SetName() override { this->MonName = "������"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};

// 2 �������� (�縷)
class Scorpion : public cMonster { // ����
public:
	// ������ �Ҹ���
	Scorpion();
	~Scorpion();

	// ���� 
	void SetName() override { this->MonName = "����"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Mummy : public cMonster { // �̶�
public:
	// ������ �Ҹ���
	Mummy();
	~Mummy();

	// ���� 
	void SetName() override { this->MonName = "�̶�"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Mimmic : public cMonster { // �̹�
public:
	// ������ �Ҹ���
	Mimmic();
	~Mimmic();

	// ���� 
	void SetName() override { this->MonName = "�̹�"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Sandman : public cMonster { // �����
public:
	// ������ �Ҹ���
	Sandman();
	~Sandman();

	// ���� 
	void SetName() override { this->MonName = "�����"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override  { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};

// 3�������� (������)
class Skeleton : public cMonster { // ��Ķ����
public:
	// ������ �Ҹ���
	Skeleton();
	~Skeleton();

	// ���� 
	void SetName() override { this->MonName = "��Ķ����"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Zombie : public cMonster { // ����
public:
	// ������ �Ҹ���
	Zombie();
	~Zombie();

	// ���� 
	void SetName() override { this->MonName = "����"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Wraith : public cMonster { // ���̽�
public:
	// ������ �Ҹ���
	Wraith();
	~Wraith();

	// ���� 
	void SetName() override { this->MonName = "���̽�"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Gagotle : public cMonster { // ������
public:
	// ������ �Ҹ���
	Gagotle();
	~Gagotle();

	// ���� 
	void SetName() override { this->MonName = "������"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};

// 4�������� (����)
class Yeti : public cMonster { // ��Ƽ
public:
	// ������ �Ҹ���
	Yeti();
	~Yeti();

	// ���� 
	void SetName() override { this->MonName = "��Ƽ"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;
	
	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Gorlem : public cMonster { // ��
public:
	// ������ �Ҹ���
	Gorlem();
	~Gorlem();

	// ���� 
	void SetName() override { this->MonName = "��"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class WereWolve : public cMonster { // �������
public:
	// ������ �Ҹ���
	WereWolve();
	~WereWolve();

	// ���� 
	void SetName() override { this->MonName = "�������"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Griffon : public cMonster { // �׸���
public:
	// ������ �Ҹ���
	Griffon();
	~Griffon();

	// ���� 
	void SetName() override { this->MonName = "�׸���"; }
	void SetMonState()override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};

// �߰� ���� 
class Mandrake : public cMonster { // �ǵ巹��ũ
public:
	// ������ �Ҹ���
	Mandrake();
	~Mandrake();

	// ���� 
	void SetName() override { this->MonName = "�ǵ巹��ũ"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Sphinx : public cMonster { // ����ũ��
public:
	// ������ �Ҹ���
	Sphinx();
	~Sphinx();

	// ���� 
	void SetName() override { this->MonName = "����ũ��"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Dullahan : public cMonster { // �����
public:
	// ������ �Ҹ���
	Dullahan();
	~Dullahan();

	// ���� 
	void SetName() override { this->MonName = "�����"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Wyvern : public cMonster { // ���̹�
public:
	// ������ �Ҹ���
	Wyvern();
	~Wyvern();

	// ���� 
	void SetName() override { this->MonName = "���̹�"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};

// ������
class Ent : public cMonster { // ��Ʈ (���������δ� ����-���� ���� �����ε� ������ ����� �������� ����)
public:
	// ������ �Ҹ���
	Ent();
	~Ent();

	// ���� 
	void SetName() { this->MonName = "��Ʈ"; }
	void SetMonState();
	void SetHp(int dam) { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Behymes : public cMonster { // ������
public:
	// ������ �Ҹ���
	Behymes();
	~Behymes();

	// ���� 
	void SetName() override { this->MonName = "������"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class Lich : public cMonster { // ��ġ
public:
	// ������ �Ҹ���
	Lich();
	~Lich();

	// ���� 
	void SetName() override { this->MonName = "��ġ"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};
class RedDragon : public  cMonster { // �巡��
public:
	// ������ �Ҹ���
	RedDragon();
	~RedDragon();

	// ���� 
	void SetName() override { this->MonName = "�巡��"; }
	void SetMonState() override;
	void SetHp(int dam) override { this->MonState.Hp -= dam; }

	void SetBurn(int turn) override;
	void SetBurnTurn() override;

	void SetBleed(int turn) override;
	void SetBleedTurn() override;

	void SetSturn(int turn) override;
	void SetSturnTurn() override;

	void SetTunt(int turn) override;
	void SetTuntTurn() override;

	// ����
	MonsterState GetMonState() const override { return this->MonState; }
	Burn GetBurn() const override { return this->burnning; }
	Bleed GetBleed() const override { return this->Bleeding; }
	Sturn GetSturn() const override { return this->Sturned; }
	Taunt GetTaunt() const override { return this->Tuanted; }
	string GetName() const override { return this->MonName; }
	void PrintMonHp() override { cout << MonState.Hp << endl; }

	// �������̵�
	void Skill_1() override;
	void Skill_2() override;
	void Skill_3() override;
	void Skill_4() override;
};