#include "Scene.h"
Screen One;		// start = 3,2		-> ���� ū��
Screen Two;		// start = 81, 2	-> one ����
Screen Three;	// start = 81,20	-> two �Ʒ�
Screen Four;	// start = 3, 20	-> one �Ʒ�

void TutorialScene() {
	Four.SetStart(3, 20);
	gotoxy(Four.GetCoord().X, Four.GetCoord().Y); 
	cout << "������ �˻� -> ������ -> ������ -> ����� -> ���� ������ �����Ѵ�."; Four.EndLine();
	gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
	cout << "���ݿ� ��� �Ǵ� ���̽��� 0 ~ 7�� ���ȸ�ü �ֻ��� 3����."; Four.EndLine();
	gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
	cout << "�������� ���̽��� ������ ������ ���͸� ������ ���õȴ�."; Four.EndLine();
	gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
	cout << "(��Ÿ�� ����, ������� ������ ������ ���� ��)"; Four.EndLine();
	gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
	cout << "�����̻��� �����̻� �ֻ��� 2���� �ٽ� ������ (�Ȱ��� �� �ȸ�ü �ֻ���)";
	gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
	cout << "ù��° �ֻ����� �����̻��� �ɼ� �ִ��� �Ǵ�"; Four.EndLine();
	gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
	cout <<	"�ι�° �ֻ����� ���� ���� �Ѵ�.";
}
void Battle(cPlayer* player[], cMonster* monster[], int Stage, int stage) {
	random_device rand;
	uniform_int_distribution<int> nRand(0, 7);
	uniform_int_distribution<int> PlayerC(0, 3);
	uniform_int_distribution<int> SkillC(1, 4);

	int choice;
	int MonChoice;
	double pst;
	clock_t start, end;

	int dice[3];
	int ccDice[2];

	int count = 0;
	int two = 1;
	int dam = 0;
	int pDeth = 4;
	int mDeth = 4;

	// �� �����ϱ����� ȭ�� �� ���� �ְ� 
	system("cls");
	// ��ũ�� �ٽ� �̰� ����
	PrintScreen();

	// �÷��̾� ����(������)
	// �˻�(2), ������(3), Ŭ����(4), �����(1) -> ������ ����
	while (true) {
		system("cls");
		PrintScreen();

		// �˻� ������, ������ ���� �̻�
		if (player[1]->GetState().Hp > 0) {
			One.SetStart(3, 2);
			PrintPlayerState(player[1]);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << player[1]->GetName() << "�� ������"; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "1. " << player[1]->GetSkill_1Name() << "\t"
				<< "2. " << player[1]->GetSkill_2Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "3. " << player[1]->GetSkill_3Name() << "\t"
				<< "4. " << player[1]->GetSkill_4Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ : ";
			cin >> choice;
			getchar();
			One.EndLine();
			if (choice == 1 || choice == 2) {
				while (true) {
					if (One.GetCoord().Y == 15) {
						system("cls");
						PrintScreen();
						One.SetStart(3, 2);

						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << player[2]->GetName() << "�� ������"; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "1. " << player[2]->GetSkill_1Name() << "\t"
							<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "3. " << player[2]->GetSkill_3Name() << "\t"
							<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "������ : " << choice; One.EndLine();
					}
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "������ ���� ��ȣ : "; One.EndLine();
					cin >> MonChoice;
					getchar();
					One.EndLine();
					MonChoice -= 1;
					if (MonChoice < 0 || MonChoice > 3) {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else if (monster[MonChoice]->GetMonState().Hp == 0) {
						if (monster[MonChoice]->GetName() != "Blank") {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�̹� ����� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
						else {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
					}
					else if (monster[MonChoice]->GetName() == "Blank") {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ùٸ��� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else break;
				}
			}
			switch (choice) {
			case 1: {
				dam = player[1]->GetState().ad;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ ���� ��ȣ : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[1]->GetSkill_1Name(); One.EndLine();
				PrintPlayerState(player[1]);
				PrintMonsterState(monster[MonChoice]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				PrintPlayerState(player[1]);
				PrintMonsterState(monster[MonChoice]);
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ����� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				monster[MonChoice]->SetHp(dam);
				cout << monster[MonChoice]->GetName() << "�� ���� ü�� : " << monster[MonChoice]->GetMonState().Hp; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
			} break;

			case 2: {
				player[3]->UseSkill();
				dam = player[1]->GetState().ap;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ ���� ��ȣ : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[1]->GetSkill_2Name(); One.EndLine();
				PrintPlayerState(player[1]);
				PrintMonsterState(monster[MonChoice]);

				// ���� �ֻ��� ������
				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "�����̻� �ֻ����� �����ϴ�.";  One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				system("pause");

				// �����̻� �ֻ��� ������
				for (int i = 0; i < 2; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 2; j++) {
							ccDice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (ccDice[0] % 2 == 0) monster[MonChoice]->SetBleed(ccDice[1]);
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << ccDice[0] << "\t" << ccDice[1]; One.EndLine();
				if (ccDice[0] % 2 == 0) {
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�����̻� : ����"; One.EndLine();
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�� : " << ccDice[1]; One.EndLine();
				}
				else {
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�����̻� : ����"; One.EndLine();
				}
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ����� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				monster[MonChoice]->SetHp(dam);
				cout << monster[MonChoice]->GetName() << "�� ���� ü�� : " << monster[MonChoice]->GetMonState().Hp; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
			}break;

			case 3: {
				dam = player[1]->GetState().adDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[1]->GetSkill_3Name(); One.EndLine();
				PrintPlayerState(player[1]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[1]->SetAdDeffence(dam);

			}break;

			case 4: {
				dam = player[1]->GetState().apDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[1]->GetSkill_4Name(); One.EndLine();
				PrintPlayerState(player[1]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[1]->SetApDeffence(dam);

			}break;

			default: {
				cout << "�ùٸ� �������� �ƴմϴ�." << endl << "�ùٸ� �������� �����ÿ�.";
			}break;
			}
			count = 0;
			two = 1;
		}
		else if (player[1]->GetState().Hp <= 0) pDeth--;
		count = 0;
		two = 1;

		system("pause");
		system("cls");
		PrintScreen();
		// ������ ������, ȭ�� �����̻�
		if (player[2]->GetState().Hp > 0) {
			PrintPlayerState(player[2]);
			One.SetStart(3, 2);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << player[2]->GetName() << "�� ������"; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "1. " << player[2]->GetSkill_1Name() << "\t"
				<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "3. " << player[2]->GetSkill_3Name() << "\t"
				<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ : ";
			cin >> choice;
			getchar();
			One.EndLine();
			if (choice == 1 || choice == 2) {
				while (true) {
					if (One.GetCoord().Y == 15) {
						system("cls");
						PrintScreen();
						One.SetStart(3, 2);

						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << player[2]->GetName() << "�� ������"; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "1. " << player[2]->GetSkill_1Name() << "\t"
							<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "3. " << player[2]->GetSkill_3Name() << "\t"
							<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "������ : " << choice; One.EndLine();
					}
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "������ ���� ��ȣ : "; One.EndLine();
					cin >> MonChoice;
					getchar();
					MonChoice -= 1;
					if (MonChoice < 0 || MonChoice > 3) {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else if (monster[MonChoice]->GetMonState().Hp == 0) {
						if (monster[MonChoice]->GetName() != "Blank") {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�̹� ����� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
						else {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
					}
					else if (monster[MonChoice]->GetName() == "Blank") {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ùٸ��� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else break;
				}
			}
			switch (choice) {
			case 1: {
				dam = player[2]->GetState().ad;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ ���� ��ȣ : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetSkill_1Name(); One.EndLine();
				PrintPlayerState(player[2]);
				PrintMonsterState(monster[MonChoice]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ����� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				monster[MonChoice]->SetHp(dam);
				cout << monster[MonChoice]->GetName() << "�� ���� ü�� : " << monster[MonChoice]->GetMonState().Hp; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
			} break;

			case 2: {
				player[3]->UseSkill();
				dam = player[2]->GetState().ap;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ ���� ��ȣ : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetSkill_2Name(); One.EndLine();
				PrintPlayerState(player[2]);
				PrintMonsterState(monster[MonChoice]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "�����̻� �ֻ����� �����ϴ�.";  One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				system("pause");

				// �����̻� �ֻ��� ������
				for (int i = 0; i < 2; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 2; j++) {
							ccDice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (ccDice[0] % 2 == 0) monster[MonChoice]->SetBleed(ccDice[1]);
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << ccDice[0] << "\t" << ccDice[1]; One.EndLine();
				if (ccDice[0] % 2 == 0) {
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�����̻� : ����"; One.EndLine();
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�� : " << ccDice[1]; One.EndLine();
				}
				else {
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�����̻� : ����"; One.EndLine();
				}
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ����� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				monster[MonChoice]->SetHp(dam);
				cout << monster[MonChoice]->GetName() << "�� ���� ü�� : " << monster[MonChoice]->GetMonState().Hp; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
			}break;

			case 3: {
				dam = player[2]->GetState().adDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetSkill_3Name(); One.EndLine();
				PrintPlayerState(player[2]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[2]->SetAdDeffence(dam);

			}break;

			case 4: {
				dam = player[2]->GetState().apDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[2]->GetSkill_1Name() << "\t"
					<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[2]->GetSkill_3Name() << "\t"
					<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[2]->GetSkill_4Name(); One.EndLine();
				PrintPlayerState(player[2]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[2]->SetApDeffence(dam);

			}break;

			default: {
				cout << "�ùٸ� �������� �ƴմϴ�." << endl << "�ùٸ� �������� �����ÿ�.";
			}break;
			}
			count = 0;
			two = 1;
		}
		else if (player[2]->GetState().Hp <= 0) pDeth--;
		count = 0;
		two = 1;

		system("pause");
		system("cls");
		PrintScreen();
		// Ŭ���� ������
		if (player[3]->GetState().Hp > 0) {
			PrintPlayerState(player[1]);
			One.SetStart(3, 2);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << player[3]->GetName() << "�� ������"; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "1. " << player[3]->GetSkill_1Name() << "\t"
				<< "2. " << player[3]->GetSkill_2Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "3. " << player[3]->GetSkill_3Name() << "\t"
				<< "4. " << player[3]->GetSkill_4Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ : ";
			cin >> choice;
			One.EndLine();
			getchar();
			if (choice == 1) {
				while (true) {
					if (One.GetCoord().Y == 15) {
						system("cls");
						PrintScreen();
						One.SetStart(3, 2);

						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << player[2]->GetName() << "�� ������"; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "1. " << player[2]->GetSkill_1Name() << "\t"
							<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "3. " << player[2]->GetSkill_3Name() << "\t"
							<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "������ : " << choice; One.EndLine();
					}
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "������ ���� ��ȣ : "; One.EndLine();
					cin >> MonChoice;
					getchar();
					MonChoice -= 1;
					if (MonChoice < 0 || MonChoice > 3) {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else if (monster[MonChoice]->GetMonState().Hp == 0) {
						if (monster[MonChoice]->GetName() != "Blank") {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�̹� ����� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
						else {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
					}
					else if (monster[MonChoice]->GetName() == "Blank") {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ùٸ��� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else break;
				}
			}
			if (choice == 2) {
				One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� �� �÷��̾� : ";
				cin >> MonChoice;
				MonChoice--;

			}
			switch (choice) {
			case 1: {
				dam = player[3]->GetState().ad;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[3]->GetSkill_1Name() << "\t"
					<< "2. " << player[3]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[3]->GetSkill_3Name() << "\t"
					<< "4. " << player[3]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ ���� ��ȣ : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetSkill_1Name(); One.EndLine();
				PrintPlayerState(player[3]);
				PrintMonsterState(monster[MonChoice]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ����� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				monster[MonChoice]->SetHp(dam);
				cout << monster[MonChoice]->GetName() << "�� ���� ü�� : " << monster[MonChoice]->GetMonState().Hp; One.EndLine();
				PrintPlayerState(player[3]);
				PrintMonsterState(monster[MonChoice]);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
			} break;

			case 2: {
				player[3]->UseSkill();
				dam = player[3]->GetState().ap;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[3]->GetSkill_1Name() << "\t"
					<< "2. " << player[3]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[3]->GetSkill_3Name() << "\t"
					<< "4. " << player[3]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� �� �÷��̾� : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetSkill_2Name(); One.EndLine();
				PrintPlayerState(player[3]);
				PrintPlayerState(player[MonChoice]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				PrintPlayerState(player[3]);
				PrintPlayerState(player[MonChoice]);
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[MonChoice]->SetHp(-dam);
				if (player[MonChoice]->GetState().Hp > player[MonChoice]->GetMaxState().Hp) player[MonChoice]->GoHotel(player[MonChoice]->GetMaxState().Hp, player[MonChoice]->GetState().Mp);
			}break;

			case 3: {
				dam = player[3]->GetState().adDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[3]->GetSkill_1Name() << "\t"
					<< "2. " << player[3]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[3]->GetSkill_3Name() << "\t"
					<< "4. " << player[3]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetSkill_3Name(); One.EndLine();
				PrintPlayerState(player[3]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[3]->SetAdDeffence(dam);

			}break;

			case 4: {
				dam = player[3]->GetState().apDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[3]->GetSkill_1Name() << "\t"
					<< "2. " << player[3]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[3]->GetSkill_3Name() << "\t"
					<< "4. " << player[3]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[3]->GetSkill_4Name(); One.EndLine();
				PrintPlayerState(player[3]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[3]->SetApDeffence(dam);

			}break;

			default: {
				cout << "�ùٸ� �������� �ƴմϴ�." << endl << "�ùٸ� �������� �����ÿ�.";
			}break;
			}
			count = 0;
			two = 1;
		}
		else if (player[3]->GetState().Hp <= 0) pDeth--;

		system("pause");
		system("cls");
		PrintScreen();
		// ��Ŀ ������
		if (player[0]->GetState().Hp > 0) {
			PrintPlayerState(player[1]);
			One.SetStart(3, 2);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << player[0]->GetName() << "�� ������"; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "1. " << player[0]->GetSkill_1Name() << "\t"
				<< "2. " << player[0]->GetSkill_2Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "3. " << player[0]->GetSkill_3Name() << "\t"
				<< "4. " << player[0]->GetSkill_4Name(); One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ : ";
			cin >> choice;
			getchar();
			One.EndLine();
			if (choice == 1 || choice == 2) {
				while (true) {
					if (One.GetCoord().Y == 15) {
						system("cls");
						PrintScreen();
						One.SetStart(3, 2);

						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << player[2]->GetName() << "�� ������"; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "1. " << player[2]->GetSkill_1Name() << "\t"
							<< "2. " << player[2]->GetSkill_2Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "3. " << player[2]->GetSkill_3Name() << "\t"
							<< "4. " << player[2]->GetSkill_4Name(); One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "������ : " << choice; One.EndLine();
					}
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "������ ���� ��ȣ : "; One.EndLine();
					cin >> MonChoice;
					One.EndLine();
					getchar();
					MonChoice -= 1;
					if (MonChoice < 0 || MonChoice > 3) {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else if (monster[MonChoice]->GetMonState().Hp == 0) {
						if (monster[MonChoice]->GetName() != "Blank") {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�̹� ����� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
						else {
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�������� ���� ���� �Դϴ�."; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "�ٽ� �����ÿ�."; One.EndLine();
						}
					}
					else if (monster[MonChoice]->GetName() == "Blank") {
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ùٸ��� ���� ���� �Դϴ�."; One.EndLine();
						gotoxy(One.GetCoord().X, One.GetCoord().Y);
						cout << "�ٽ� �����ÿ�.";
					}
					else break;
				}
			}
			switch (choice) {
			case 1: {
				dam = player[0]->GetState().ad;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[0]->GetSkill_1Name() << "\t"
					<< "2. " << player[0]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[0]->GetSkill_3Name() << "\t"
					<< "4. " << player[0]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ ���� ��ȣ : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetSkill_1Name(); One.EndLine();
				PrintPlayerState(player[0]);
				PrintMonsterState(monster[MonChoice]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ����� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				if (dam % 3 == 0) {
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << monster[MonChoice]->GetName() << "�� �����ϴµ� �����ߴ�."; One.EndLine();
				}
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				monster[MonChoice]->SetHp(dam);
				cout << monster[MonChoice]->GetName() << "�� ���� ü�� : " << monster[MonChoice]->GetMonState().Hp; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
			} break;

			case 2: {
				player[3]->UseSkill();
				dam = player[0]->GetState().ap;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[0]->GetSkill_1Name() << "\t"
					<< "2. " << player[0]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[0]->GetSkill_3Name() << "\t"
					<< "4. " << player[0]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ ���� ��ȣ : " << MonChoice + 1; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetSkill_2Name(); One.EndLine();
				PrintPlayerState(player[0]);
				PrintMonsterState(monster[MonChoice]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "�����̻� �ֻ����� �����ϴ�.";  One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				system("pause");

				// �����̻� �ֻ��� ������
				for (int i = 0; i < 2; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 2; j++) {
							ccDice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (ccDice[0] % 2 == 0) monster[MonChoice]->SetBleed(ccDice[1]);
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << ccDice[0] << "\t" << ccDice[1]; One.EndLine();
				if (ccDice[0] % 2 == 0) {
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�����̻� : ����"; One.EndLine();
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�� : " << ccDice[1]; One.EndLine();
				}
				else {
					gotoxy(One.GetCoord().X, One.GetCoord().Y);
					cout << "�����̻� : ����"; One.EndLine();
				}
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ����� : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				monster[MonChoice]->SetHp(dam);
				cout << monster[MonChoice]->GetName() << "�� ���� ü�� : " << monster[MonChoice]->GetMonState().Hp; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
			}break;

			case 3: {
				dam = player[0]->GetState().adDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[0]->GetSkill_1Name() << "\t"
					<< "2. " << player[0]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[0]->GetSkill_3Name() << "\t"
					<< "4. " << player[0]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetSkill_3Name(); One.EndLine();
				PrintPlayerState(player[0]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[0]->SetAdDeffence(dam);

			}break;

			case 4: {
				dam = player[0]->GetState().apDef;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetName() << "�� ������"; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "1. " << player[0]->GetSkill_1Name() << "\t"
					<< "2. " << player[0]->GetSkill_2Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "3. " << player[0]->GetSkill_3Name() << "\t"
					<< "4. " << player[0]->GetSkill_4Name(); One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "������ : " << choice; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << player[0]->GetSkill_4Name(); One.EndLine();
				PrintPlayerState(player[0]);

				for (int i = 0; i < 3; i++) {
					start = clock();
					do {
						Three.SetStart(81, 20);
						for (int j = i; j < 3; j++) {
							dice[j] = nRand(rand);
						}
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ֻ�����"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "����������"; Three.EndLine();
						gotoxy(Three.GetCoord().X, Three.GetCoord().Y);
						cout << "�ƹ�Ű�� ���� ����"; Three.EndLine();
						end = clock();
						pst = (double)(end - start) / CLK_TCK;
					} while (!_kbhit() || (pst < 1)); //1�ʾȿ� Ȥ�� Ű�� �������
					getchar();
					if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
						dam = 0;
						i = 3;
					}
					if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
						dam = 0;
						i = 3;
					}
					if (dice[0] == dice[1] && dice[1] == dice[2]) {
						i = 0;
						count++;
					}
				}

				for (int i = 0; i < count; i++) two *= 2;
				dam *= two;
				system("cls");
				PrintScreen();
				One.SetStart(3, 2);
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);
				cout << "���� ���ġ : " << dam; One.EndLine();
				gotoxy(One.GetCoord().X, One.GetCoord().Y);

				player[0]->SetApDeffence(dam);

			}break;

			default: {
				cout << "�ùٸ� �������� �ƴմϴ�." << endl << "�ùٸ� �������� �����ÿ�.";
			}break;
			}
			count = 0;
			two = 1;
		}
		else if (player[0]->GetState().Hp <= 0) pDeth--;

		One.EndLine();
		system("pause");
		gotoxy(One.GetCoord().X, One.GetCoord().Y);
		cout << "������ �������� ���۵˴ϴ�.";
		system("cls");
		PrintScreen();
		// ���� ������
		for (int i = 3; i > -1; i--) {
			int mChoice, plChoice;
			system("cls");
			PrintScreen();
			One.SetStart(3, 2);
			Four.SetStart(3, 20);
			PrintMonsterState(monster[i]);
			if (monster[i]->GetName() != "Blank") {
				if (monster[i]->GetMonState().Hp != 0) {
				if (monster[i]->GetBleed().bleeding == true) {
					monster[i]->SetBleedTurn();
					monster[i]->SetHp(monster[i]->GetMonState().Hp * (1 / 10));
					gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
					cout << "������ �ɷ� �ֽ��ϴ�."; Four.EndLine();
					gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
					cout << "����� : " << (monster[i]->GetMonState().Hp * (1 / 10)); Four.EndLine();
				}
				if (monster[i]->GetBurn().burn == true) {
					monster[i]->SetBurnTurn();
					monster[i]->SetHp(monster[i]->GetMonState().Hp * (1 / 10));
					gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
					cout << "ȭ�� �ɷ� �ֽ��ϴ�."; Four.EndLine();
					gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
					cout << "����� : " << (monster[i]->GetMonState().Hp * (1 / 10)); Four.EndLine();
				}
				if (monster[i]->GetSturn().sturn != true) {
					if (monster[1]->GetMonState().Hp != 0) {

						if (monster[i]->GetTaunt().taunt == true) {
							gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
							cout << "���߿� �ɷ� �ִ�."; Four.EndLine();
							plChoice = 0;
							if (player[plChoice]->GetState().Hp != 0) {
								monster[i]->SetTuntTurn();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << monster[i]->GetName() << "�� ������"; One.EndLine();
								dam = monster[i]->GetMonState().ad;
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << monster[i]->GetSkill_1Name(); One.EndLine();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);

								for (int i = 0; i < 3; i++) {
									for (int j = 0; j < 10000; j++) dice[i] = nRand(rand);
									if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
										dam = 0;
										i = 3;
									}
									if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
										dam = 0;
										i = 3;
									}
									if (dice[0] == dice[1] && dice[1] == dice[2]) {
										i = 0;
										count++;
									}
								}

								for (int i = 0; i < count; i++) two *= 2;
								system("cls");
								PrintScreen();
								One.SetStart(3, 2);
								cout << monster[i]->GetName() << "�� ������"; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "1. " << monster[i]->GetSkill_1Name() << "\t"
									<< "2. " << monster[i]->GetSkill_2Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "3. " << monster[i]->GetSkill_3Name() << "\t"
									<< "4. " << monster[i]->GetSkill_4Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ : 1"; One.EndLine();

								dam *= two;
								dam /= 3;
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "Ÿ�ݿ� ����� ���� ���ؿ���." << count; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "���� ����� : " << dam; One.EndLine();

								player[plChoice]->SetHp(dam);
							}
							else {
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << player[plChoice]->GetName() << "��(��) �̹� ��������."; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << monster[i]->GetName() << "�� ������ϴ�."; One.EndLine();
							}
						}

						if (monster[i]->GetTaunt().taunt != true) {
							PrintMonsterState(monster[i]);
							One.SetStart(3, 2);
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << monster[i]->GetName() << "�� ������"; One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "1. " << monster[i]->GetSkill_1Name() << "\t"
								<< "2. " << monster[i]->GetSkill_2Name(); One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "3. " << monster[i]->GetSkill_3Name() << "\t"
								<< "4. " << monster[i]->GetSkill_4Name(); One.EndLine();
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							cout << "������ : ";
							Sleep(1500);
							cout << SkillC(rand); One.EndLine();
							while (true) {
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ �÷��̾� ��ȣ : ";
								Sleep(1500);
								plChoice = PlayerC(rand);
								if (player[plChoice]->GetState().Hp == 0) {
									plChoice = PlayerC(rand);
								}
								else {
									cout << plChoice + 1; One.EndLine();
									break;
								}
							}
							gotoxy(One.GetCoord().X, One.GetCoord().Y);
							system("pause");
							switch (choice) {
							case 1: {
								system("cls");
								PrintScreen();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								dam = monster[i]->GetMonState().ad;
								cout << monster[i]->GetSkill_1Name(); One.EndLine();

								for (int i = 0; i < 3; i++) {
									for (int j = 0; j < 10000; j++) dice[i] = nRand(rand);
									if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
										dam = 0;
										i = 3;
									}
									if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
										dam = 0;
										i = 3;
									}
									if (dice[0] == dice[1] && dice[1] == dice[2]) {
										i = 0;
										count++;
									}
								}

								for (int i = 0; i < count; i++) two *= 2;
								dam *= two;

								system("cls");
								PrintScreen();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << monster[i]->GetName() << "�� ������"; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "1. " << monster[i]->GetSkill_1Name() << "\t"
									<< "2. " << monster[i]->GetSkill_2Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "3. " << monster[i]->GetSkill_3Name() << "\t"
									<< "4. " << monster[i]->GetSkill_4Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ : " << choice; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ �÷��̾� ��ȣ : " << plChoice + 1; One.EndLine();
								if (player[plChoice]->GetDeffence().adDef != 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().adDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									if (dam <= player[plChoice]->GetDeffence().adDef) {
										dam = 0;
										player[plChoice]->SetAdDeffence(-dam);
									}
									if (dam > player[plChoice]->GetDeffence().adDef) {
										dam -= player[plChoice]->GetDeffence().adDef;
										player[plChoice]->SetAdDeffence(-player[plChoice]->GetDeffence().adDef);
									}
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
								if (player[plChoice]->GetDeffence().adDef == 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().adDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
							} break;

							case 2: {
								system("cls");
								PrintScreen();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								dam = monster[i]->GetMonState().ap;
								cout << monster[i]->GetSkill_2Name(); One.EndLine();

								for (int i = 0; i < 3; i++) {
									for (int j = 0; j < 10000; j++) dice[i] = nRand(rand);
									if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
										dam = 0;
										i = 3;
									}
									if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
										dam = 0;
										i = 3;
									}
									if (dice[0] == dice[1] && dice[1] == dice[2]) {
										i = 0;
										count++;
									}
								}

								for (int i = 0; i < count; i++) two *= 2;
								dam *= two;
								system("cls");
								PrintScreen();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << monster[i]->GetName() << "�� ������"; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "1. " << monster[i]->GetSkill_1Name() << "\t"
									<< "2. " << monster[i]->GetSkill_2Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "3. " << monster[i]->GetSkill_3Name() << "\t"
									<< "4. " << monster[i]->GetSkill_4Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ : " << choice; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ �÷��̾� ��ȣ : " << plChoice + 1; One.EndLine();
								if (player[plChoice]->GetDeffence().apDef != 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().apDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									if (dam <= player[plChoice]->GetDeffence().apDef) {
										dam = 0;
										player[plChoice]->SetApDeffence(-dam);
									}
									if (dam > player[plChoice]->GetDeffence().apDef) {
										dam -= player[plChoice]->GetDeffence().apDef;
										player[plChoice]->SetApDeffence(-player[plChoice]->GetDeffence().apDef);
									}
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
								if (player[plChoice]->GetDeffence().apDef == 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().adDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
							} break;

							case 3: {
								system("cls");
								PrintScreen();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								dam = monster[i]->GetMonState().ad;
								cout << monster[i]->GetSkill_3Name(); One.EndLine();

								for (int i = 0; i < 3; i++) {
									for (int j = 0; j < 10000; j++) dice[i] = nRand(rand);
									if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
										dam = 0;
										i = 3;
									}
									if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
										dam = 0;
										i = 3;
									}
									if (dice[0] == dice[1] && dice[1] == dice[2]) {
										i = 0;
										count++;
									}
								}

								for (int i = 0; i < count; i++) two *= 2;
								dam *= two;

								system("cls");
								PrintScreen();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << monster[i]->GetName() << "�� ������"; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "1. " << monster[i]->GetSkill_1Name() << "\t"
									<< "2. " << monster[i]->GetSkill_2Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "3. " << monster[i]->GetSkill_3Name() << "\t"
									<< "4. " << monster[i]->GetSkill_4Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ : " << choice; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ �÷��̾� ��ȣ : " << plChoice + 1; One.EndLine();
								if (player[plChoice]->GetDeffence().adDef != 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().adDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									if (dam <= player[plChoice]->GetDeffence().adDef) {
										dam = 0;
										player[plChoice]->SetAdDeffence(-dam);
									}
									if (dam > player[plChoice]->GetDeffence().adDef) {
										dam -= player[plChoice]->GetDeffence().adDef;
										player[plChoice]->SetAdDeffence(-player[plChoice]->GetDeffence().adDef);
									}
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
								if (player[plChoice]->GetDeffence().adDef == 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().adDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
							} break;

							case 4: {
								system("cls");
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								PrintScreen();
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								dam = monster[i]->GetMonState().ap;
								cout << monster[i]->GetSkill_4Name(); One.EndLine();

								for (int i = 0; i < 3; i++) {
									for (int j = 0; j < 10000; j++) dice[i] = nRand(rand);
									if (i != 0 && dice[i - 1] == dice[i] && dice[i] == 0) {
										dam = 0;
										i = 3;
									}
									if (i == 2 && dice[i] == 0 && dice[0] == dice[i]) {
										dam = 0;
										i = 3;
									}
									if (dice[0] == dice[1] && dice[1] == dice[2]) {
										i = 0;
										count++;
									}
								}

								for (int i = 0; i < count; i++) two *= 2;
								dam *= two;
								system("cls");
								PrintScreen();
								PrintMonsterState(monster[i]);
								PrintPlayerState(player[plChoice]);
								One.SetStart(3, 2);
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << monster[i]->GetName() << "�� ������"; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "1. " << monster[i]->GetSkill_1Name() << "\t"
									<< "2. " << monster[i]->GetSkill_2Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "3. " << monster[i]->GetSkill_3Name() << "\t"
									<< "4. " << monster[i]->GetSkill_4Name(); One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ : " << choice; One.EndLine();
								gotoxy(One.GetCoord().X, One.GetCoord().Y);
								cout << "������ �÷��̾� ��ȣ : " << plChoice + 1; One.EndLine();
								if (player[plChoice]->GetDeffence().apDef != 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().apDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									if (dam <= player[plChoice]->GetDeffence().apDef) {
										dam = 0;
										player[plChoice]->SetApDeffence(-dam);
									}
									if (dam > player[plChoice]->GetDeffence().apDef) {
										dam -= player[plChoice]->GetDeffence().apDef;
										player[plChoice]->SetApDeffence(-player[plChoice]->GetDeffence().apDef);
									}
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
								if (player[plChoice]->GetDeffence().apDef == 0) {
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << dice[0] << "\t" << dice[1] << "\t" << dice[2]; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "Ʈ���� Ƚ�� : " << count; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "��� ��� ��� : " << player[plChoice]->GetDeffence().adDef; One.EndLine();
									gotoxy(One.GetCoord().X, One.GetCoord().Y);
									cout << "���� ����� : " << dam; One.EndLine();
									player[plChoice]->SetHp(dam);
								}
							} break;
							}
							count = 0;
							two = 1;
						}

					}
					
					if (monster[i]->GetName() == "Blank") mDeth--;
				}
				if (monster[i]->GetSturn().sturn == true) {
					gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
					cout << "���Ͽ� �ɷ� �����ϼ� ����.";
					monster[i]->SetSturnTurn();
				}
			}
			gotoxy(Four.GetCoord().X, Four.GetCoord().Y);
			if(monster[i]->GetName() != "Blank")system("pause");
		}

		// ���� üũ
		if (pDeth == 0) {
			system("cls");
			PrintScreen();
			One.SetStart(3, 2);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "��Ƽ�� ���� ����� �Ҿ���."; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "�������� ��Ƽ������ �߰ߵ� ������ ���ư���."; One.EndLine();
			break;
		}
		else if (mDeth == 0) {
			system("cls");
			PrintScreen();
			One.SetStart(3, 2);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "��� ���͸� ��ġ����."; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "���� �������� ���ϴ� ���� ã�Ҵ�."; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "�ϴ��� ������ ���ư� ���� ������ �غ�����."; One.EndLine();
			int exp, Max, Min;
			for (int i = 0; i < 4; i++) {
				if (i == 0) Max = monster[i]->GetMonState().EXP;
				else {
					if (Max > monster[i]->GetMonState().EXP) Max = monster[i]->GetMonState().EXP;
					else Min = monster[i]->GetMonState().EXP;
				}
				exp = (Min + Max) / 2;
			}
			for (int i = 0; i < 4; i++) {				
				player[i]->SetExp(exp);
			}
			break;
		}
		else{
		/*
			�÷��̾� �迭�̳� ���� �迭�� �ϳ��� ���� ���� ��� ���ƾ���,
			���� �ϴ��� ��� üũ�ϰ� ������. 
			Ư�� ������ ��쿡�� �������� ���� ���Ͱ� ���� �Ǳ� ������
			��Ʋ �ȿ��� ������ ���� ���͸� ����Ʈ �� �ʿ�� ����,
			���� �ϴ� �����ϳ��� ���, ������ ���ư��� �ϸ鼭 
			�ʿ� ������ ���͵� ������ ���� �Ѵ�.
		*/  
			pDeth = 4;
			mDeth = 4;
		}
	}
	}
}
void StageManeger(int Stage, int stage, cPlayer* player[], cMonster* monster[]) {
	switch (Stage) {
	case 1: {
		switch (stage) {
		case 1: {
			cout << "1-1 Stage" << endl;
			monster[0] = new Slime();
			monster[1] = new Slime();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 2: {
			cout << "1-2 Stage" << endl;
			monster[0] = new Slime();
			monster[1] = new Gobllin();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 3: {
			cout << "1-3 Stage" << endl;
			monster[0] = new Slime();
			monster[1] = new Gobllin();
			monster[2] = new Kobold();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 4: {
			cout << "1-4 Stage" << endl;
			monster[0] = new Mandrake();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 5: {
			cout << "1-5 Stage" << endl;
			monster[0] = new Slime();
			monster[1] = new Gobllin();
			monster[2] = new Kobold();
			monster[3] = new LizardMan();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 6: {
			cout << "1-6 Stage" << endl;
			monster[0] = new Gobllin();
			monster[1] = new Gobllin();
			monster[2] = new Kobold();
			monster[3] = new LizardMan();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 7: {
			cout << "1-7 Stage" << endl;
			monster[0] = new Kobold();
			monster[1] = new Kobold();
			monster[2] = new LizardMan();
			monster[3] = new LizardMan();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 8: {
			cout << "1-8 Stage" << endl;
			monster[0] = new Ent();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;
		}

	}break;

	case 2: {
		switch (stage) {
		case 1: {
			cout << "2-1 Stage" << endl;
			monster[0] = new Scorpion();
			monster[1] = new Scorpion();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 2: {
			cout << "2-2 Stage" << endl;
			monster[0] = new Scorpion();
			monster[1] = new Mummy();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 3: {
			cout << "2-3 Stage" << endl;
			monster[0] = new Scorpion();
			monster[1] = new Mummy();
			monster[2] = new Mimmic();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 4: {
			cout << "2-4 Stage" << endl;
			monster[0] = new Sphinx();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 5: {
			cout << "2-5 Stage" << endl;
			monster[0] = new Scorpion();
			monster[1] = new Mummy();
			monster[2] = new Mimmic();
			monster[3] = new Sandman();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 6: {
			cout << "2-6 Stage" << endl;
			monster[0] = new Mummy();
			monster[1] = new Mummy();
			monster[2] = new Mimmic();
			monster[3] = new Sandman();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 7: {
			cout << "2-7 Stage" << endl;
			monster[0] = new Mimmic();
			monster[1] = new Mimmic();
			monster[2] = new Sandman();
			monster[3] = new Sandman();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 8: {
			cout << "2-8 Stage" << endl;
			monster[0] = new Behymes();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;
		}

	}break;

	case 3: {
		switch (stage) {
		case 1: {
			cout << "3-1 Stage" << endl;
			monster[0] = new Skeleton();
			monster[1] = new Skeleton();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 2: {
			cout << "3-2 Stage" << endl;
			monster[0] = new Skeleton();
			monster[1] = new Zombie();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 3: {
			cout << "3-3 Stage" << endl;
			monster[0] = new Skeleton();
			monster[1] = new Zombie();
			monster[2] = new Wraith();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 4: {
			cout << "3-4 Stage" << endl;
			monster[0] = new Dullahan();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 5: {
			cout << "3-5 Stage" << endl;
			monster[0] = new Skeleton();
			monster[1] = new Zombie();
			monster[2] = new Wraith();
			monster[3] = new Gagotle();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 6: {
			cout << "3-6 Stage" << endl;
			monster[0] = new Zombie();
			monster[1] = new Zombie();
			monster[2] = new Wraith();
			monster[3] = new Gagotle();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 7: {
			cout << "3-7 Stage" << endl;
			monster[0] = new Wraith();
			monster[1] = new Wraith();
			monster[2] = new Gagotle();
			monster[3] = new Gagotle();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 8: {
			cout << "2-1 Stage" << endl;
			monster[0] = new Lich();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;
		}

	}break;

	case 4: {
		switch (stage) {
		case 1: {
			cout << "4-1 Stage" << endl;
			monster[0] = new Yeti();
			monster[1] = new Yeti();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 2: {
			cout << "4-2 Stage" << endl;
			monster[0] = new Yeti();
			monster[1] = new Gorlem();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 3: {
			cout << "4-3 Stage" << endl;
			monster[0] = new Yeti();
			monster[1] = new Gorlem();
			monster[2] = new WereWolve();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 4: {
			cout << "4-4 Stage" << endl;
			monster[0] = new Wyvern();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 5: {
			cout << "4-5 Stage" << endl;
			monster[0] = new Yeti();
			monster[1] = new Gorlem();
			monster[2] = new WereWolve();
			monster[3] = new Griffon();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 6: {
			cout << "4-6 Stage" << endl;
			monster[0] = new Gorlem();
			monster[1] = new Gorlem();
			monster[2] = new WereWolve();
			monster[3] = new Griffon();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 7: {
			cout << "4-7 Stage" << endl;
			monster[0] = new WereWolve();
			monster[1] = new WereWolve();
			monster[2] = new Griffon();
			monster[3] = new Griffon();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;

		case 8: {
			cout << "4-8 Stage" << endl;
			monster[0] = new RedDragon();
			monster[1] = new Blank();
			monster[2] = new Blank();
			monster[3] = new Blank();
			for (int i = 0; i < 4; i++)monster[i]->SetName();
			for (int i = 0; i < 4; i++)monster[i]->SetMonState();
			for (int i = 0; i < 4; i++)monster[i]->Skill_1();
			for (int i = 0; i < 4; i++)monster[i]->Skill_2();
			for (int i = 0; i < 4; i++)monster[i]->Skill_3();
			for (int i = 0; i < 4; i++)monster[i]->Skill_4();
			Battle(player, monster, Stage, stage);
			for (int i = 0; i < 4; i++) delete monster[i];
			for (int i = 0; i < 4; i++) player[i]->SetLevel();
		}break;
		}

	}break;
	default:
		break;
	}
}
void Place(PLACE& ePlace) {
	One.SetStart(3, 2);
	switch (ePlace) {
	case PLACE::ENUM_TOWN: {
		gotoxy(One.GetCoord().X, One.GetCoord().Y); One.EndLine();
		cout << "���� ��ġ : ����";
	} break;
	case PLACE::ENUM_HOTEL: {
		gotoxy(One.GetCoord().X, One.GetCoord().Y); One.EndLine();
		cout << "���� ��ġ : ����";
	} break;
	case PLACE::ENUM_Tutorial: {
		gotoxy(One.GetCoord().X, One.GetCoord().Y); One.EndLine();
		cout << "���� ��ġ : ���� ������ ��";
	} break;
	default:
		break;
	}
	gotoxy(One.GetCoord().X, One.GetCoord().Y);
	cout << "1. ���� \t 2. ����"; One.EndLine();
	gotoxy(One.GetCoord().X, One.GetCoord().Y);
	cout << "3. Ʃ�丮�� ������ \t 4. ����"; One.EndLine();
	gotoxy(One.GetCoord().X, One.GetCoord().Y);
	cout << "�̵��� ��Ҹ� �Է��Ͻÿ� : ";
	int place;
	cin >> place;
	One.EndLine();
	switch (place) {
	case 1: {
		if (ePlace != PLACE::ENUM_TOWN) {
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ �̵��մϴ�."; One.EndLine();
			Sleep(1500);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ �����߽��ϴ�.";
			Sleep(1500);
			One.EndLine();
			ePlace = PLACE::ENUM_TOWN;
		}
		else {
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "�̹� ������ �ֽ��ϴ�"; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			system("pause");
		}
		
	} break;
	case 2: {
		if (ePlace != PLACE::ENUM_HOTEL) {
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "�������� �̵��մϴ�."; One.EndLine();
			Sleep(1500);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ �����߽��ϴ�.";
			Sleep(1500);
			ePlace = PLACE::ENUM_HOTEL;
		}
		else {
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "�̹� ������ �ֽ��ϴ�"; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			system("pause");
		}
	} break;
	case 3: {
		if (ePlace != PLACE::ENUM_Tutorial) {
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ �������� ���� ���� �̵��մϴ�."; One.EndLine();
			Sleep(1500);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ ������ �տ� �����߽��ϴ�."; One.EndLine();
			Sleep(500);
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "���� ��Ŀ� ���� ���� ���ִ�."; One.EndLine();
			Sleep(1500);
			ePlace = PLACE::ENUM_Tutorial;
		}
		else {
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "������ �������� ���� �ִ�"; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			cout << "���� ��ĸ��� ���� �ִ� ���� �Ⱥ��δ�."; One.EndLine();
			gotoxy(One.GetCoord().X, One.GetCoord().Y);
			system("pause");
		}
	} break;
	case 4: {
		gotoxy(One.GetCoord().X, One.GetCoord().Y);
		cout << "�������� �̵��ϱ� ���� ���� ������ �����ϴ�."; One.EndLine();
		Sleep(1500);
		gotoxy(One.GetCoord().X, One.GetCoord().Y);
		cout << "���� �տ� �����ߴ�."; One.EndLine();
		gotoxy(One.GetCoord().X, One.GetCoord().Y);
		cout << "������ �ȳ��� ����ϴ� ������ ������."; One.EndLine();
		Sleep(1500);
		ePlace = PLACE::ENUM_DUNGEON;
	} break;
	default: {
		One.SetStart(3, 2);
		gotoxy(One.GetCoord().X, One.GetCoord().Y);
		cout << "���� ���� �����Դϴ�."; One.EndLine();
		gotoxy(One.GetCoord().X, One.GetCoord().Y);
		cout << "�ٸ� �������� �����ÿ�"; One.EndLine();
	} break;
	}
}
void gotoxy(int x, int y) {
	COORD Pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
void PrintPlayerState(cPlayer* player){
	Two.SetStart(81, 2);
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "�̸�	: " << player->GetName(); Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "����	: " << player->GetLevel() ; Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "����ġ	: " << player->GetEXP() << " / " << player->GetMaxState().MaxEXP; Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "ü��	: " << player->GetState().Hp << " / " << player->GetMaxState().Hp; Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "����	: " << player->GetState().Mp << " / " << player->GetMaxState().Mp; Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "���ݷ�	: " << player->GetState().ad << " / " << player->GetState().ap; Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "����	: " << player->GetState().adDef 
		<< "(" << player->GetDeffence().adDef << ")" 
		<< " / " << player->GetState().apDef 
		<< "(" << player->GetDeffence().apDef << ")"; Two.EndLine();
}
void PrintMonsterState(cMonster* monster){
	Two.SetStart(81, 10);
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "�̸�	: " << monster->GetName(); Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "ü��	: " << monster->GetMonState().Hp;  Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "����	: " << monster->GetMonState().Hp; Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "�����̻�: " << monster->GetBleed().turn << "/" << monster->GetBurn().turn << "/" << monster->GetSturn().turn << "/" << monster->GetTaunt().turn; Two.EndLine();
	gotoxy(Two.GetCoord().X, Two.GetCoord().Y);
	cout << "����, ȭ��, ����, ����";
	
}